#include <iostream>
#include <map>
#include <vector>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <string>
#include <list>

using namespace std;

/*
* The name of the file to load.
* 
* This file should reside in the same folder as the executable. Main will look for it there.
*/
const string fileName = "InputDataCourses.csv";

/*
* A function that takes a line of delimeter separated values and splits them into a vector
* 
* Parameters
* str = the line of input to split
* delimiter = the char value that is being used as the delimting character.
*/
vector<string> split(string str, char delimiter) {
	vector<string> internalVector;
	stringstream theStream(str);
	string token;
	while (getline(theStream, token, delimiter)) {
		internalVector.push_back(token);
	}
	return internalVector;
}

/*
* A Class structure that defines a Course.
* 
* Defines a default constructor with no parameters.
* 
* Defines an alternate constructor that takes a line of input data.
* 
* Exceptions
*   Throws an exception is a line of data contains less than 2 elements. (Courses must have at least an Id and a Title)
*   Throws an exception if the Course points to itself as a prerequisite
*   Throws an exception if the Course points to a higher level course as a prerequisite. (Possible Cycle)
*/
class Course {

private:

public:
    Course() {};                    // Public Default Constructor
    Course(string line) {           // An overloaded constructor that takes a line of input.
        vector<string> tokens = split(line, ',');
        if (tokens.size() < 2) { throw exception("Invalid record encoutered in the input file."); }

        // Set basic object properties
        this->Id = tokens.at(0);
        this->Title = tokens.at(1);

        // breaks element 0 into two strings used for error checking.
        this->Program = tokens.at(0).substr(0, 4);
        this->CourseNumber = tokens.at(0).substr(4);

        // Deals with the remaining elements as Prerequisites.
        for (int x = 2; x < tokens.size();x++) {
            if (tokens.at(x) == this->Id) {
                throw exception("Invalid record: Course cannot point to itself as a prerequisite.");
            }
            string newCourseId = tokens.at(x);
            int newCourseNumber = 0;
            if (!newCourseId.empty()) {
                newCourseNumber = stoi(newCourseId.substr(4));
            }
            if (newCourseNumber > stoi(this->CourseNumber)) {
                throw exception("Invalid record: Possible Cycle Detected.");
            }
            this->Prerequisites.push_back(tokens.at(x));
        }

    };        
	string Id;                  // The Course's Id
	string Title;               // The Course's Title
    string Program;
    string CourseNumber;
	list<string> Prerequisites; // A list of Course Prerequisites
};


/*
* A function that loads the data. This function reads a line of data from the file specified by the inputFile
* parameter and creates a vector of lines.
* 
* Parameters
* 
* inputFile = the name of the file to read for input. Fully Qualified Path.
* 
* Returns a vector of strings.
*/
vector<string> GetData(string inputFile) {
    vector<string> linesOfData;
    std::string line;
    ifstream ifile(inputFile.c_str());
    if (ifile.is_open())
    {
        while (ifile.good())
        {
            getline(ifile, line);
            if (line != "") {
                linesOfData.push_back(line);
            }
        }
        ifile.close();

    }
    else {
        throw exception("Failed to open input file. ");
    }
    return linesOfData;
}



/*
* A function to build a hashtable of prerequisites for a given course. This function is recursive. It will call
* itself so long as it has prerequisites to deal with.
* 
* Parameters
* 
* course = A given instance of a Course Object.
*/
void GetPrerequisites(Course course, map<string,Course> &Courses, map<string,Course> &Prerequisites) {
    for (auto CourseId : course.Prerequisites) {
        Course c = Courses[CourseId];
        Prerequisites[CourseId] = c; // This is done to eliminate duplicates in the prerequisiste list.
        GetPrerequisites(c, Courses, Prerequisites);
    }
}



/*
* A function that prints the prerequisites contained in the prerequisites map.
* 
* This map is temporary, it will get cleared every time a new course is selected.
*/
void PrintPrerequisites(map<string, Course> &Prerequisites) {
    for (auto course : Prerequisites) {
        cout << "\t" << course.first << " " << course.second.Title << endl;
    }
}



/*
* Program Entry Point.
*/
int main(int argc, char* argv[]) {

    // Gets the path to running executable.
    string inputFile = argv[0];             
    
    // Strips out the name of the executable.
    string::size_type n;
    n = inputFile.rfind("\\");
    inputFile = inputFile.substr(0, n+1 );


    // Create the hash table that will hold course object keyed by Course Id.
    map<string, Course> Courses;

    // Create a hashtable to temporarily hold Prerequisite courses.
    map<string, Course> Prerequisites;

    // Create a vector of strings to hold data from the file.
    vector<string> linesOfData;

    // A string to hold the Course Number the user selectes.
    string CourseNumber;

    // Hold the course object for printing prerequisites
    Course c;

    // Initialize the menu selection variable.
    char inputValue = '0';

    // Starts the loop for the menu.
    while (inputValue != 9) {

        // *** Start Menu Code
        cout.flush();
        system("cls");
        cout << "ABC University" << endl << endl;
        cout << "Please select the number that corresponds to your choice of action." << endl << endl;
        cout << "1 - Load Course Data." << endl;
        cout << "2 - Display a listing of Courses sorted by Course Id." << endl;
        cout << "3 - Display a Course and all the Prerequisites Required." << endl;
        cout << "9 - Exit the Program." << endl << endl;
        cout << "Please Enter Choice: ";
        cin >> inputValue;
        // **** End Menu Code

        // *** Start Menu Switch
        switch (inputValue) {

        // The user selects option to load the data.
        case '1': 
            linesOfData = GetData(inputFile + fileName);

            // Creating Course Objects is wrapped in a try/catch to gracefully handle errors thrown by the constructor
            try {
                for (auto line : linesOfData) {
                    Course course = Course(line);
                    Courses.insert(pair<string, Course>(course.Id, course));
                }
            }

            // Handle errors
            catch (exception ex) {
                cout << "The program encountered an issue loading the data. The error reported was;" << endl << endl;
                cout << ex.what() << endl << endl;
                system("pause");
                Courses.clear();
                break;
            }

            cout << endl << endl;
            cout << linesOfData.size() << " Courses loaded" << endl;
            system("pause");
            break;



        // User selects option to print a complete course listing
        case '2': 
            if (Courses.size() > 0) {
               cout << endl << endl;
               cout << "Complete Course Listing" << endl << endl;
               for (auto course : Courses) {
                    cout << course.first << " " << course.second.Title << endl;
                    if (course.second.Prerequisites.size() > 0) {
                        for (auto preReq : course.second.Prerequisites) {
                            if (preReq.empty()) { continue; }
                            cout << "\t" << "Prerequisite --- " << Courses[preReq].Id << " " << Courses[preReq].Title << endl;
                        }
                    }
                    else
                    {
                        cout << "\t" << "No Prerequisites";
                    }
                    cout << endl;
                }
            }
            else {
                cout << endl << endl;
                cout << "There are no courses loaded. Please select option 1 first..." << endl;
            }
            cout << endl << endl;
            system("pause");
            break;



        // User selects option to print a prerequisite list.
        case '3': 
            if (Courses.size() < 1) {
                cout << endl << endl;
                cout << "There are no courses loaded. Please select option 1 first..." << endl;
            }
            else {
                cout << endl;
                cout << "Please enter the course number you wish to view: ";
                cin >> CourseNumber;
                c = Courses[CourseNumber];
                if (c.Id == "") {
                    cout << endl;
                    cout << "The Course you are looking for was not found." << endl;
                    system("pause");
                    break;
                }
                cout << endl;
                cout << "This listing includes the complete chain of prerequisite courses for " << CourseNumber << endl;
                cout << endl;
                cout << c.Id << " " << c.Title << endl;
                cout << "----------------------------------------------" << endl;
                Prerequisites.clear(); // clears the hashtable of old entries.
                GetPrerequisites(c, Courses, Prerequisites); // This method is recursive.
                if (Prerequisites.size() > 1) {
                    cout << "Prerequisites for " << c.Id << endl;
                    PrintPrerequisites(Prerequisites);
                }
                else {
                    cout << c.Id << " has no prerequisites." << endl;
                }
                cout << endl;
            }
            cout << endl << endl;
            system("pause");
            break;


        // Handles invalid menu entries.
        default: 
            cout << endl;
            cout << "You entered an invalid choice. Please try again..." << endl;
            break;


        // Exits the program
        case '9':
            return 0;
        }
        // *** End Menu Switch
    }

}

